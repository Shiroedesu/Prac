
<?php
	
	$conn = mysqli_connect('localhost','root','','his') or die('Connection failed!');
?>