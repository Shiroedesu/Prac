# Certificate-Generator
Generate PDF certificate using JavaScript

This app uses two library PDF-lib.js and FileSaver.js

![Screenshot](https://i.imgur.com/H7mcyZ3.png)

# Certificate Sample
![Sample pdf](https://i.imgur.com/GFGU3K9.jpg)
